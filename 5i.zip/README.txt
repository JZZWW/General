Jonasz Zbigniew Witczak (vkg337)
15/10 - 2022

Åben src mappen. Heri ligger zip.filen 5iproj. Udpak denne til en vilkårlig tom mappe. Dernæst åben terminalen/kommando prompten 
og ved brug af "cd" kommandoen skift directory til mappen. Her kan nu køres kommandoenrne "dotnet build" og "dotnet run" i terminalen, 
så længe .NET 6.0 er installeret. 