Jonasz Zbigniew Witczak (vkg337)
17/09-2022